<div class="footer container-fluid bg-dark text-light">
    <p class="text-center py-2 mb-0">Cologne Crafters </p>
</div>
